/**
 * Payroll Components
 */

export { default as PayslipDocument, downloadPayslip, generatePayslipBlob } from './PayslipPDF';
